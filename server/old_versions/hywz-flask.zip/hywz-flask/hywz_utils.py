# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 13:00:10 2018

@author: Alec Shinn
"""
from datetime import datetime as dt
from re import sub

def create_file_name_from_datetime(file_type='jpg'):
     fn = '{}.{}'.format(str(dt.now().strftime("%c")), file_type)
     fn = sub(' ', '_', fn)
     fn = sub(':','-', fn)
     return fn
 
if __name__ == '__main__':
    print(create_file_name_from_datetime())
    print(create_file_name_from_datetime())