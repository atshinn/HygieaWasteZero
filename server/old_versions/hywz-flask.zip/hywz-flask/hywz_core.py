# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 14:05:39 2018

@author: Alec
"""
from google.cloud.vision_v1 import ImageAnnotatorClient
from google.cloud import vision
from google.oauth2.service_account import Credentials
from google.api_core import retry
from traceback import format_exc
import boto3 as aws
import google as G

_AWS_ACCESS_KEY_ID = 'AKIAIVABEJNTQ76CZGVQ'
_AWS_SECRET_ACCESS_KEY = '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'
_AWS_S3_BUCKET = 'hywz.wastezero'

_G_CREDS = Credentials.from_service_account_file(r'resources\gcvServiceKey.json')
_G_CLIENT = vision.ImageAnnotatorClient(credentials=_G_CREDS)


def create_resource_json_response(res_name):
    res = {}
    res['resource'] = res_name
    res['resourceLocation'] = '
    
    
def detect_img_labels(img_bin):
    global cpath
    my_retry = retry.Retry(deadline=60)
    creds = Credentials.from_service_account_file(r'gcvServiceKey.json')
    client = ImageAnnotatorClient(credentials=creds)
    image = vision.types.Image(content=img_bin)
    response = client.label_detection(image,my_retry,timeout=10)
    return response.label_annotations


def decide(arg):
    #array of recycle words
    arg=str(arg)
    recycle = ['plastic', 'aluminum', 'bottle', 'recycle', 'recyclable', 'paper']
    #if the word from Json is the one that needs to be read is there
    if type(arg) == type(''):
        for i in recycle:
            if i in arg.lower():
                return 'Recycle'
        return 'Compost'
    
    else:
        return 'error'


def call_vision(img_bin):
    global _G_CREDS
    # Instantiates a client
    
    client = vision.ImageAnnotatorClient(credentials=_G_CREDS)
    image = vision.types.Image(content=img_bin)

    # Performs label detection on the image file
    response = client.label_detection(image=image, retry=2, timeout=10)

    labels = response.label_annotations
    
    return decide(str(labels))