from flask import Flask, request_started, request
from traceback import format_exc
import hywz_subroutines as subrout
import os


application = app = Flask(__name__)


@app.before_first_request
def init_setup_request():
    try:
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = os.path.join(app.root_path,os.environ['GOOGLE_CRED_FILE'])
    except KeyError:
        raise Exception('ENIVRONMENT VARIABLE NOT FOUND')
    
    
    
def before_each_request(sender,**extra):
    print('inside before each request', str(type(sender)))
    
    if not os.path.exists(os.environ['GOOGLE_APPLICATION_CREDENTIALS']):
        raise Exception('GOOGLE_APPLICATION_CREDENTIALS NOT VALID FILEPATH')
    else:
        print(os.environ['GOOGLE_APPLICATION_CREDENTIALS'])
    

@app.route('/trash',methods=['POST','PUT','GET'])
def upload_image():
    try:
        
        if request.method == 'POST':
            return subrout.post_trash_routine(request)
        
        elif request.method == 'GET':
            return subrout.get_all_trash_routine()
    except Exception:
        return str(format_exc())


@app.route('/trash/<string:resource_id>', methods=['GET','DELETE'])
def get_or_delete_trash(resource_id):
    if request.method == 'GET':
        return subrout.get_trash_routine(request, resource_id)    
    else:
        return resource_id


@app.route('/')
def landing():
    print('HEEERE')
    if(app.debug):
        return str(os.environ)
    return "landing page for hywz"


request_started.connect(before_each_request, app)


if __name__ == '__main__':
    application.run(debug=True)